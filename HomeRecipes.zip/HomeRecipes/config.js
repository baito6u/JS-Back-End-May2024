module.exports = {
    SECRET: "1340144dwmqdoqwdmqwdo12meo1io4i124mo21eddiqwmo3i4141"
}